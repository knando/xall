package aula2809;

public class Aluno {
	String nome;
	String username;
	int matricula;
	String email;
	boolean estaAtivo;
	int ano;
	
	public Aluno(String nome, int matricula, boolean estaAtivo, int ano) {
		super();
		this.nome = nome;
		this.username = "" + matricula;
		this.matricula = matricula;
		this.email = this.matricula + "@escola.com";
		this.estaAtivo = estaAtivo;
		this.ano = ano;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getMatricula() {
		return matricula;
	}
	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public boolean isEstaAtivo() {
		return estaAtivo;
	}
	public void setEstaAtivo(boolean estaAtivo) {
		this.estaAtivo = estaAtivo;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	
	@Override
	public String toString() {
		return "Aluno " + nome + ", (" + matricula + "), " + email
				+ "," + estaAtivo + ", " + ano + "";
	}
}
