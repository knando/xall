package aula2809;

public class Professor {
	String nome;
	String username;
	String email;
	int contrato;
	boolean estaAtivo;
	
	public Professor(String nome, int contrato, boolean estaAtivo) {
		super();
		this.nome = nome;
		this.username = this.nome.split(" ")[0];
		this.email = this.username + "@escola.com";
		this.contrato = contrato;
		this.estaAtivo = estaAtivo;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getContrato() {
		return contrato;
	}
	public void setContrato(int contrato) {
		this.contrato = contrato;
	}
	public boolean isEstaAtivo() {
		return estaAtivo;
	}
	public void setEstaAtivo(boolean estaAtivo) {
		this.estaAtivo = estaAtivo;
	}
	@Override
	public String toString() {
		return "Professor [nome=" + nome + ", username=" + username + ", email=" + email + ", contrato=" + contrato
				+ ", estaAtivo=" + estaAtivo + "]";
	}
}
