package aula2809;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Principal {
	void main() {
		Turma t1 = new Turma();
		t1.setListaAlunos(new ArrayList<>());
		Aluno a1 = new Aluno("João Rodrigo", 122, true, 2026);
		Aluno a2 = new Aluno("Jesse Vitor", 413, true, 2026);
		Aluno a3 = new Aluno("Arthur Julia", 411, true, 2026);
		Aluno a4 = new Aluno("Amanda Gomes", 292, true, 2026);
		Aluno a5 = new Aluno("Lucas Lherme", 152, true, 2026);
		t1.adicionaAluno(a1);
		t1.adicionaAluno(a2);
		t1.adicionaAluno(a3);
		t1.adicionaAluno(a4);
		t1.adicionaAluno(a5);
		t1.setProfessor(new Professor("Luiz Cesar", 21, true));
		t1.setCodigo("t208");
		
		JOptionPane.showMessageDialog(null, t1);
	}
}
