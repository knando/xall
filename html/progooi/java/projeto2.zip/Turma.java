package aula2809;

import java.util.List;

public class Turma {
	List<Aluno> listaAlunos;
	Professor professor;
	String codigo;
	
	public void adicionaAluno(Aluno aluno) {
		this.listaAlunos.add(aluno);
	}

	public void removeAluno(Aluno aluno) {
		this.listaAlunos.remove(aluno);
	}
	
	public List<Aluno> getListaAlunos() {
		return listaAlunos;
	}
	public void setListaAlunos(List<Aluno> listaAlunos) {
		this.listaAlunos = listaAlunos;
	}
	public Professor getProfessor() {
		return professor;
	}
	public void setProfessor(Professor professor) {
		this.professor = professor;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	@Override
	public String toString() {
		return "Turma [\nlistaAlunos=" + listaAlunos + "\nprofessor=" + professor + ", codigo=" + codigo + "]";
	}
}
