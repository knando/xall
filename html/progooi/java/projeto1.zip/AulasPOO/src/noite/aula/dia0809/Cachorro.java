package noite.aula.dia0809;

import java.time.LocalDate;

public class Cachorro {
	private String nome;
	private String raca;
	private int idade;
	private int anoCadastro;
	private double peso;
	
	public Cachorro() {
		this.anoCadastro = LocalDate.now().getYear();
	}
	
	public Cachorro(String nome, String raca, int idade, double peso) {
		this.nome = nome;
		this.raca = raca;
		this.idade = idade;
		this.anoCadastro = LocalDate.now().getYear();
		this.peso = peso;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		// TODO validar tamanho mínimo de nome
		this.nome = nome;
	}

	public String getRaca() {
		return raca;
	}

	public void setRaca(String raca) {
		// TODO validar tamanho máximo de nome de raça
		if (raca == null || raca.length() < 3) {
			Dialogo d = new Dialogo();
			d.mostraErro("Raça precisa ter ao menos 3 letras. Pode ser SRD (Sem raça definida)");
		} else {
			this.raca = raca;
		}
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		// TODO idade não pode ser menor que 0
		if (idade >= 30) {
			Dialogo d = new Dialogo();
			d.mostraErro("Cão não pode ter nascido há mais de 30 anos.");
		} else {
			this.idade = idade;
		}
	}

	public int getAno() {
		return anoCadastro;
	}

	public void setAno(int ano) {
		this.anoCadastro = ano;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		// TODO validar peso mínimo
		if (peso > 70) {
			Dialogo d = new Dialogo();
			d.mostraErro("Peso não pode ser superior a 70kg.");
		} else {
			this.peso = peso;
		}
	}
}
