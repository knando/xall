package noite.aula.dia0809;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	void main() {
		List<Cachorro> lista = new ArrayList<>();
		int opcao = 0;
		Dialogo tela = new Dialogo();

		do {
			opcao = tela.perguntaInt("Escolha uma opção:\n1: Cadastrar cachorro" +
					"\n2: Listar cachorros\n3: Remover cachorro\n4: Atualizar peso" +
					"\n5: Listar cachorros de um dono\n0 ou menos: Sair");
			switch(opcao) {
			case 1:
				//Cadastrar cachorro
				String nomeCriar = tela.pergunta("Qual o nome do cachorro?");
				String raca = tela.pergunta("Qual a raça do cachorro?");
				int idade = tela.perguntaInt("Qual a idade do cachorro?");
				double peso = tela.perguntaDouble("Qual o peso do cachorro?");
				Cachorro cao = new Cachorro(nomeCriar, raca, idade, peso);
				lista.add(cao);
				break;
			case 2:
				StringBuilder sb = new StringBuilder("Os cachorros são:");
				for(Cachorro c : lista) {
					sb.append(c.toString());
				}
				tela.mostraMensagem(sb.toString());
				break;
			case 3:
				String nomeRemover = tela.pergunta("Qual o nome do cachorro a remover?");
				int posicaoCachorroRemover = 0;
				// TODO qual o cachorro certo a remover?
				for(int i = 0; i < lista.size(); i++) {
					// ??
					posicaoCachorroRemover = i;
				}
				lista.remove(posicaoCachorroRemover);
				break;
			case 4:
				// TODO atualizar peso de um cachorro

				break;
			case 5:
				String nomeDonoProcurar = tela.pergunta("Qual o nome do dono?");
				// TODO listar caes cujo dono tenha esse nome
				break;
			default:
				tela.mostraMensagem("Obrigado por usar o sistema!");
				break;
			}

		} while (opcao > 0);
	}
}
