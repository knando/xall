package noite.aula.dia0809;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	void main() {
		List<Cachorro> lista = new ArrayList<>();
		lista.add(new Cachorro("Beethoven", "São Bernardo", 7, 68));
		lista.add(new Cachorro("Snoopy", "Beagle", 10, 30));
		lista.add(new Cachorro("Floquinho", "Lhasa Apso", 3, 18));
		lista.add(new Cachorro("Caramelo", "SRD", 8, 15));
		
		int opcao = 0;
		Dialogo tela = new Dialogo();

		do {
			opcao = tela.perguntaInt("Escolha uma opção:\n1: Cadastrar cachorro" +
					"\n2: Listar cachorros\n3: Remover cachorro\n4: Atualizar peso" +
					"\n5: Listar cachorros de um dono\n0 ou menos: Sair");
			switch(opcao) {
			case 1:
				Cachorro cao = new Cachorro();
				String nomeCriar = tela.pergunta("Qual o nome do cachorro?");
				cao.setNome(nomeCriar);
				String raca = tela.pergunta("Qual a raça do cachorro?");
				cao.setRaca(raca);
				int idade = tela.perguntaInt("Qual a idade do cachorro?");
				cao.setIdade(idade);
				double peso = tela.perguntaDouble("Qual o peso do cachorro?");
				cao.setPeso(peso);
				lista.add(cao);
				break;
			case 2:
				StringBuilder sb = new StringBuilder("Os cachorros são:");
				for(Cachorro c : lista) {
					sb.append(c.toString());
				}
				tela.mostraMensagem(sb.toString());
				break;
			case 3:
				String nomeRemover = tela.pergunta("Qual o nome do cachorro a remover?");
				int posicaoCachorroRemover = 0;
				// TODO qual o cachorro certo a remover?
				for(int i = 0; i < lista.size(); i++) {
					lista.get(i); // Obtém cachorro
					posicaoCachorroRemover = i;
				}
				lista.remove(posicaoCachorroRemover);
				break;
			case 4:
				// TODO atualizar peso de um cachorro

				break;
			case 5:
				String nomeDonoProcurar = tela.pergunta("Qual o nome do dono?");
				// TODO listar caes cujo dono tenha esse nome
				break;
			default:
				tela.mostraMensagem("Obrigado por usar o sistema!");
				break;
			}

		} while (opcao > 0);
	}
}
