package noite.aula.dia0809;

import javax.swing.JOptionPane;

public class Dialogo {
	public Dialogo() {}
	
	public void mostraErro(String mensagem) {
		JOptionPane.showMessageDialog(null, mensagem, "Erro", JOptionPane.ERROR_MESSAGE);
	}
	
	public void mostraMensagem(String mensagem) {
		JOptionPane.showMessageDialog(null, mensagem);
	}
	
	public int perguntaInt(String pergunta) {
		String resposta = JOptionPane.showInputDialog(pergunta);
		return Integer.parseInt(resposta);
	}
	
	public double perguntaDouble(String pergunta) {
		String resposta = JOptionPane.showInputDialog(pergunta);
		return Double.parseDouble(resposta);
	}
	
	public String pergunta(String pergunta) {
		return JOptionPane.showInputDialog(pergunta);
	}
}
